package com.example.chesspedagogue;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chesspedagogue.repository.GameRepository;
import com.example.chesspedagogue.viewmodel.GameViewModel;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    // Core components
    private StockfishManager engine;
    private AudioConversationManager convo;
    private ChessGameManager gameManager;
    private AudioConversationManager audioConversationManager;
    private static final int PERMISSION_REQUEST_MICROPHONE = 101;
    private ChessCoachConversationManager chessCoachConversation;

    private FloatingActionButton voiceChatButton;
    private boolean conversationModeActive = false;
    private RealtimeConversationManager realtimeManager;
    private ConversationIntegrationHelper integrationHelper;




    // Voice controller definition
    private ChessCoachManager.VoiceRecognitionController voiceController =
            new ChessCoachManager.VoiceRecognitionController() {
                @Override
                public void startListening() {
                    startVoiceRecognition();
                }

                @Override
                public boolean isInConversationMode() {
                    return inConversationMode;
                }
            };

    private ChessBoardView boardView;
    private ChessCoachManager chessCoach;
    private SpeechRecognitionManager speechRecognitionManager;

    // Game state
    private String playerColorChoice;
    private boolean isPlayerTurn = true;
    private String lastMove = "";

    // UI components
    private TextView statusTextView;
    private CardView coachMessageCard;
    private TextView coachMessageText;
    private Button askFollowUpButton;
    private Button dismissCoachButton;
    private FloatingActionButton chessCoachButton;
    private FloatingActionButton voiceInputButton;
    private FloatingActionButton conversationButton;

    private Vibrator vibrator;

    // Move history tracking
    private TextView moveHistoryTextView;
    private StringBuilder moveHistoryBuilder = new StringBuilder();
    private int moveNumber = 1;
    private List<String> algebraicMoveHistory = new ArrayList<>();

    // Chat panel variables
    private View chatPanel;
    private View dragHandle;
    private float initialY;
    private float initialTouchY;
    private boolean isPanelVisible = false;
    private Animation slideUpAnimation;
    private Animation slideDownAnimation;
    private LinearLayout coachBottomSheet;
    private TextView bottomSheetMessageText;
    private Button bottomSheetRespondButton;
    private Button bottomSheetDismissButton;
    private BottomSheetBehavior<LinearLayout> bottomSheetBehavior;

    // Add these variables to your MainActivity class
    private boolean inConversationMode = false;
    private int conversationTurns = 0;
    private GameViewModel gameViewModel;

    // Configuration
    private static final String API_KEY = "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";
    private static final String SYSTEM_PROMPT = "You are Coach Tal…";
    private static final int MAX_CONVERSATION_TURNS = 5; // Prevent infinite loops

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize ViewModel
        gameViewModel = new ViewModelProvider(this).get(GameViewModel.class);

        // ---------- ONE and only ONE AudioConversationManager ----------
        TextView transcript = findViewById(R.id.transcript);
        audioConversationManager = new AudioConversationManager(transcript);
        audioConversationManager.setApiKey(ApiKeyConfig.getApiKey(this));   // or hard‑code
        audioConversationManager.setSystemPrompt(SYSTEM_PROMPT);

        initializeRealtimeConversation();

        audioConversationManager.setConversationListener(new AudioConversationManager.ConversationListener() {
            @Override
            public void onStateChanged(AudioConversationManager.State s) {
                runOnUiThread(() -> {
                    switch (s) {
                        case CONNECTING:
                            bottomSheetMessageText.setText("Connecting…");
                            break;
                        case LISTENING:
                            bottomSheetMessageText.setText("I'm listening!");
                            break;
                        case PROCESSING:
                            bottomSheetMessageText.setText("Thinking…");
                            break;
                        case SPEAKING:
                            /* text arrives via onPartial/onText */
                            break;
                        case IDLE:
                            bottomSheetMessageText.setText("Tap mic to talk");
                            break;
                    }
                });
            }


            @Override
            public void onConnected() {
                Log.d(TAG, "CONNECTION ESTABLISHED - NOW starting conversation");

                // Check network availability first
                if (!isNetworkAvailable()) {
                    Toast.makeText(MainActivity.this,
                            "⚠️ No network connection detected", Toast.LENGTH_LONG).show();
                }

                Toast.makeText(MainActivity.this,
                        "Coach connected 🙌", Toast.LENGTH_SHORT).show();

                // Start conversation
                runOnUiThread(() -> {
                    audioConversationManager.startConversation();
                    bottomSheetMessageText.setText("I'm listening! Ask me about your chess game...");

                    // Optional: Uncomment to test with a manual message after 5 seconds
                    // testWebSocketCommunication();
                });
            }


            @Override
            public void onTextResponse(String t) {
                bottomSheetMessageText.setText(t);
            }

            @Override
            public void onPartialResponse(String p) {
                bottomSheetMessageText.setText(p);
            }

            @Override
            public void onError(String m) {
                Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show();
            }
        });

        // Set up observers for LiveData
        setupObservers();

        playerColorChoice = getIntent().getStringExtra("PLAYER_COLOR");
        if (playerColorChoice == null) playerColorChoice = "white";

        // Connect chess board view click listener
        boardView = findViewById(R.id.chessBoardView);
        boardView.setOnSquareTapListener(new ChessBoardView.OnSquareTapListener() {
            @Override
            public void onSquareTapped(int row, int col) {
                handleBoardTap(row, col);
            }
        });

        // Get settings from SplashActivity
        int skillLevel = getIntent().getIntExtra("SKILL_LEVEL", 10);

        // Find UI components
        boardView = findViewById(R.id.chessBoardView);
        statusTextView = findViewById(R.id.statusTextView);
        moveHistoryTextView = findViewById(R.id.moveHistoryTextView);
        moveHistoryBuilder = new StringBuilder();
        moveNumber = 1;

        // Chess coach components
        coachMessageCard = findViewById(R.id.coachMessageCard);
        coachMessageText = findViewById(R.id.coachMessageText);
        askFollowUpButton = findViewById(R.id.askFollowUpButton);
        dismissCoachButton = findViewById(R.id.dismissCoachButton);
        chessCoachButton = findViewById(R.id.chessCoachButton);
        voiceInputButton = findViewById(R.id.voiceInputButton);
        conversationButton = findViewById(R.id.conversationButton);
        coachBottomSheet = findViewById(R.id.coachBottomSheet);
        bottomSheetMessageText = findViewById(R.id.bottomSheetMessageText);
        bottomSheetRespondButton = findViewById(R.id.bottomSheetRespondButton);
        bottomSheetDismissButton = findViewById(R.id.bottomSheetDismissButton);

        // Initialize the bottom sheet behavior
        bottomSheetBehavior = BottomSheetBehavior.from(coachBottomSheet);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);

        // Get or create chessCoach
        chessCoach = ChessCoachManager.getInstance(this);
        chessCoach.connectToGameViewModel(gameViewModel);

        // Initialize audio conversation
        initializeAudioConversation();

        // Set up bottom sheet click listener
        coachBottomSheet.setOnClickListener(v -> {
            // Interrupt speech and start listening when user taps anywhere on the sheet
            if (chessCoach.interruptAndListen()) {
                Toast.makeText(MainActivity.this, "Listening...", Toast.LENGTH_SHORT).show();
            }
        });

        // Add this to handle tapping on the coach's message to interrupt
        bottomSheetMessageText.setOnClickListener(v -> {
            // Interrupt speech and start listening when user taps the message
            if (chessCoach.interruptAndListen()) {
                Toast.makeText(MainActivity.this, "Listening...", Toast.LENGTH_SHORT).show();
            }
        });

        // Settings button setup
        Button settingsButton = findViewById(R.id.settingsButton);
        if (settingsButton != null) {
            settingsButton.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Error: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                    Log.e("MainActivity", "Error launching settings", e);
                }
            });
        }

        // Set up bottom sheet drag handle
        View bottomSheetDragHandle = findViewById(R.id.bottomSheetDragHandle);
        bottomSheetDragHandle.setOnTouchListener(new View.OnTouchListener() {
            private float initialY;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialY = coachBottomSheet.getY();
                        initialTouchY = event.getRawY();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float currentY = event.getRawY();
                        float deltaY = currentY - initialTouchY;

                        // Convert to bottom sheet state
                        if (deltaY < -50) { // Dragging up
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                        } else if (deltaY > 50) { // Dragging down
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        return true;
                }
                return false;
            }
        });

        // Set a lower peek height that won't block the board
        int peekHeightDp = 72; // Just enough for buttons and a line of text
        int peekHeightPx = (int) (peekHeightDp * getResources().getDisplayMetrics().density);
        bottomSheetBehavior.setPeekHeight(peekHeightPx);

        // Set maximum height to prevent full coverage of board
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        int maxHeight = screenHeight / 3; // Maximum 1/3 of screen height
        bottomSheetBehavior.setMaxHeight(maxHeight);

        // Add this right after initializing coach components
        coachMessageCard.setOnClickListener(v -> {
            // Interrupt speech and start listening when user taps the message
            if (chessCoach.interruptAndListen()) {
                Toast.makeText(MainActivity.this, "Listening...", Toast.LENGTH_SHORT).show();
            }
        });

        // Initialize chat panel components
        chatPanel = findViewById(R.id.chatPanel);
        if (chatPanel != null) {
            dragHandle = chatPanel.findViewById(R.id.dragHandle);

            // Set up slide animations
            slideUpAnimation = AnimationUtils.loadAnimation(this, R.anim.slide_up);
            slideDownAnimation = AnimationUtils.loadAnimation(this, R.anim.slide_down);

            // Set up drag handle touch listener
            setupDragHandleTouchListener();

            // Set up conversation button for continuous voice interaction
            if (conversationButton != null) {
                conversationButton.setOnClickListener(v -> {
                    startVoiceConversation();
                });
            }
        }

        // Set up respond button
        bottomSheetRespondButton.setOnClickListener(v -> {
            startVoiceRecognition();
        });

        // Set up dismiss button
        bottomSheetDismissButton.setOnClickListener(v -> {
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
            chessCoach.stopSpeaking();
        });

        // Initialize chess coach
        initializeChessCoach();

        voiceInputButton.setOnClickListener(v -> {
            // Show a simple dialog with options
            String[] options = {"Voice command", "Type a question"};

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Chess Coach Input");
            builder.setItems(options, (dialog, which) -> {
                if (which == 0) {
                    // Voice input
                    startVoiceRecognition();
                } else {
                    // Text input - show the chat panel
                    toggleChatPanel();
                }
            });
            builder.show();
        });

        chessCoachButton.setOnClickListener(v -> {
            // Get current game analysis
            String fen = engine.getCurrentFEN();
            showLoading("Coach is analyzing your position...");
            GameStateInfo gameState = new GameStateInfo(fen, algebraicMoveHistory, playerColorChoice);
            chessCoach.getEnhancedChessAdvice(gameState, new ChessCoachCallback());
        });

        askFollowUpButton.setOnClickListener(v -> {
            promptForFollowUpQuestion();
        });

        dismissCoachButton.setOnClickListener(v -> {
            hideCoachMessage();
        });

        conversationButton.setOnClickListener(v -> {
            Log.d(TAG, "Top button clicked, starting conversation");
            if (inConversationMode) {
                stopVoiceConversation();
            } else {
                startVoiceConversation();
            }
        });

        // Initialize sound manager
        SoundManager.initialize(this);

        // Get vibrator service
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        // Show initial status
        updateStatusText("Starting game...");

        // Initialize speech recognition
        initializeSpeechRecognition();

        // Load saved game after engine initialization
        loadSavedGameIfNeeded();

        // Check for and prompt for API key if needed
        promptForApiKeyIfNeeded();

        // Initialize the engine using the native library approach
        initializeStockfishEngine(skillLevel);

        // Setup game analysis button
        Button gameAnalysisButton = findViewById(R.id.gameAnalysisButton);
        if (gameAnalysisButton != null) {
            gameAnalysisButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, GameAnalysisActivity.class);
                intent.putStringArrayListExtra("MOVE_HISTORY", new ArrayList<>(algebraicMoveHistory));
                startActivity(intent);
            });
        }
    }

    // Helper methods moved outside of onCreate

    private void startVoiceConversation() {
        // Add at the start of startVoiceConversation() method
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "CRITICAL ERROR: Missing RECORD_AUDIO permission!");
            Toast.makeText(this, "Microphone permission required", Toast.LENGTH_LONG).show();
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    PERMISSION_REQUEST_MICROPHONE);
            return;
        }
        try {
            Log.d(TAG, "Starting voice conversation");

            // Check if audio manager is null
            if (audioConversationManager == null) {
                Log.e(TAG, "Audio conversation manager is null, initializing now");
                audioConversationManager = new AudioConversationManager(findViewById(R.id.transcript));
            }

            // Make sure we have the API key
            String apiKey = ApiKeyConfig.getApiKey(this);
            if (apiKey == null || apiKey.isEmpty()) {
                Log.e(TAG, "API key is missing - cannot start conversation");
                Toast.makeText(this, "Please set your OpenAI API key in settings first", Toast.LENGTH_LONG).show();
                return;
            }

            String maskedKey = apiKey.substring(0, 5) + "..." +
                    (apiKey.length() > 10 ? apiKey.substring(apiKey.length() - 5) : "");
            Log.d(TAG, "Using API key: " + maskedKey);

            // Set up system prompt for chess coaching
            String systemPrompt = "You are Coach Tal, a brilliant attacking chess master and the 8th World Chess Champion. " +
                    "Your tactical vision and creativity are legendary. When analyzing positions, you MUST:\n\n" +
                    "- Begin your VERY FIRST SENTENCE by directly referencing a specific move from the history\n" +
                    "- If at starting position: \"I see we're at the starting position with no moves played yet.\"\n" +
                    "- NEVER give generic advice without tying it to specific moves in THIS game\n" +
                    "- Look for tactical opportunities and creative possibilities, just as Tal would";

            audioConversationManager.setSystemPrompt(systemPrompt);

            // Update UI immediately
            inConversationMode = true;
            conversationButton.setImageResource(android.R.drawable.ic_media_pause);
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
            bottomSheetMessageText.setText("Connecting to your chess coach...");

            // CRITICAL CHANGE: Set a proper conversation listener with onConnected override
            audioConversationManager.setConversationListener(new AudioConversationManager.ConversationListener() {
                @Override
                public void onStateChanged(AudioConversationManager.State s) {
                    runOnUiThread(() -> {
                        switch (s) {
                            case IDLE:
                                bottomSheetMessageText.setText("Tap mic to talk");
                                break;
                            case CONNECTING:
                                bottomSheetMessageText.setText("Connecting...");
                                break;
                            case LISTENING:
                                bottomSheetMessageText.setText("I'm listening!");
                                break;
                            case PROCESSING:
                                bottomSheetMessageText.setText("Thinking...");
                                break;
                            case SPEAKING:
                                // Text arrives via onPartial/onText
                                break;
                        }
                    });
                }

                @Override
                public void onConnected() {
                    Log.d(TAG, "CONNECTION ESTABLISHED - NOW starting conversation");
                    Toast.makeText(MainActivity.this,
                            "Coach connected 🙌", Toast.LENGTH_SHORT).show();

                    // CRITICAL: Only start conversation AFTER connection is established
                    runOnUiThread(() -> {
                        audioConversationManager.startConversation();
                        bottomSheetMessageText.setText("I'm listening! Ask me about your chess game...");
                    });
                }

                @Override
                public void onTextResponse(String t) {
                    bottomSheetMessageText.setText(t);
                }

                @Override
                public void onPartialResponse(String p) {
                    bottomSheetMessageText.setText(p);
                }

                @Override
                public void onError(String m) {
                    Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show();
                }
            });

            // First connect, then let the callback handle starting the conversation
            Log.d(TAG, "Connecting to WebSocket first, will start conversation in onConnected callback");
            audioConversationManager.connect(apiKey);

        } catch (Exception e) {
            Log.e(TAG, "Error starting voice conversation", e);
            Toast.makeText(this, "Error starting conversation: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private void stopVoiceConversation() {
        audioConversationManager.endConversation();
        inConversationMode = false;
        conversationButton.setImageResource(android.R.drawable.ic_media_play);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
    }

    private void setupObservers() {
        gameViewModel.getCurrentFEN().observe(this, fen -> {
            if (fen != null) {
                boardView.updateBoardFromFen(fen);
                Log.d(TAG, "Board updated with FEN: " + fen);
            }
        });

        gameViewModel.getStatusMessage().observe(this, message -> {
            if (message != null) {
                statusTextView.setText(message);
            }
        });

        gameViewModel.isPlayerTurn().observe(this, isPlayerTurn -> {
            this.isPlayerTurn = isPlayerTurn != null && isPlayerTurn;
        });

        gameViewModel.isGameOver().observe(this, isGameOver -> {
            if (isGameOver != null && isGameOver) {
                Toast.makeText(this, "Game over!", Toast.LENGTH_LONG).show();
            }
        });

        gameViewModel.getLastMoveEvent().observe(this, coordinates -> {
            if (coordinates != null && coordinates.length == 4) {
                boardView.setLastMove(
                        coordinates[0], coordinates[1],
                        coordinates[2], coordinates[3]
                );
            }
        });

        gameViewModel.getMoveHistory().observe(this, moves -> {
            if (moves != null) {
                updateMoveHistoryView(moves);
                algebraicMoveHistory = new ArrayList<>(moves);
            }
        });

        gameViewModel.getKingInCheckEvent().observe(this, kingPosition -> {
            if (kingPosition != null) {
                boardView.setKingInCheck(true, kingPosition[0], kingPosition[1]);
                SoundManager.playSound("check");
                performHapticFeedback("check");
            } else {
                boardView.setKingInCheck(false, -1, -1);
            }
        });

        gameViewModel.getAnimateMoveEvent().observe(this, coordinates -> {
            if (coordinates != null && coordinates.length == 4) {
                boardView.animateMove(coordinates[0], coordinates[1], coordinates[2], coordinates[3]);
                String moveUci = convertToUCI(coordinates[0], coordinates[1], coordinates[2], coordinates[3]);
                String moveType = determineMoveType(moveUci, gameViewModel.getCurrentFEN().getValue());
                SoundManager.playSound(moveType);
                performHapticFeedback(moveType);
            }
        });
    }

    private void initializeAudioConversation() {
        // Get API key from secure storage if available
        String apiKey = ApiKeyConfig.getApiKey(this);
        if (apiKey != null && !apiKey.isEmpty()) {
            audioConversationManager.setApiKey(apiKey);
        }
    }

    private void onUserMove(String fenOrText) {
        convo.sendUserText(fenOrText);
    }

    private void loadSavedGameIfNeeded() {
        long gameId = getIntent().getLongExtra("LOAD_GAME_ID", -1);
        if (gameId != -1) {
            try {
                Log.d(TAG, "Starting to load saved game #" + gameId);
                playerColorChoice = getIntent().getStringExtra("PLAYER_COLOR");
                ArrayList<String> loadedMoves = getIntent().getStringArrayListExtra("MOVE_HISTORY");
                String finalFen = getIntent().getStringExtra("FINAL_FEN");

                if (loadedMoves != null && !loadedMoves.isEmpty()) {
                    algebraicMoveHistory = new ArrayList<>(loadedMoves);
                    engine.newGame();

                    Log.d(TAG, "Applying moves to rebuild game state...");
                    for (String move : loadedMoves) {
                        gameManager.makeMove(move);
                        Log.d(TAG, "Applied move: " + move);
                    }

                    GameStateRepository.updateState(
                            finalFen != null ? finalFen : engine.getCurrentFEN(),
                            algebraicMoveHistory,
                            playerColorChoice
                    );
                    Log.d(TAG, "Game state repository updated with loaded game data");

                    updateBoardDisplay();
                    moveHistoryBuilder = new StringBuilder();
                    moveNumber = 1;
                }
            } catch (Exception e) {
                Log.e(TAG, "Error loading game: " + e.getMessage(), e);
                Toast.makeText(this, "Error loading game: " + e.getMessage(), Toast.LENGTH_LONG).show();
                setupChessBoard();
            }
        } else {
            Log.d(TAG, "No saved game to load, setting up new game");
            setupChessBoard();
        }
    }

    private void setupDragHandleTouchListener() {
        if (dragHandle == null) return;

        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialY = chatPanel.getY();
                        initialTouchY = event.getRawY();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float newY = initialY + (event.getRawY() - initialTouchY);
                        float minY = getWindowManager().getDefaultDisplay().getHeight() -
                                convertDpToPx(450);
                        float maxY = getWindowManager().getDefaultDisplay().getHeight() -
                                convertDpToPx(150);

                        if (newY < minY) newY = minY;
                        if (newY > maxY) newY = maxY;

                        chatPanel.setY(newY);
                        return true;

                    case MotionEvent.ACTION_UP:
                        return true;

                    default:
                        return false;
                }
            }
        });
    }

    private float convertDpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    private void toggleChatPanel() {
        if (chatPanel == null) return;

        if (isPanelVisible) {
            chatPanel.startAnimation(slideDownAnimation);
            chatPanel.setVisibility(View.GONE);
        } else {
            chatPanel.setVisibility(View.VISIBLE);
            chatPanel.startAnimation(slideUpAnimation);

            RecyclerView recyclerView = chatPanel.findViewById(R.id.recyclerViewChat);
            if (recyclerView.getAdapter() == null) {
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                List<ChatMessage> messages = new ArrayList<>();
                messages.add(new ChatMessage(ChatMessage.TYPE_COACH,
                        "Hello! I'm Coach Tal. How can I help with your chess game?"));
                ChatAdapter adapter = new ChatAdapter(messages);
                recyclerView.setAdapter(adapter);

                EditText messageInput = chatPanel.findViewById(R.id.editTextMessage);
                ImageButton sendButton = chatPanel.findViewById(R.id.buttonSend);

                sendButton.setOnClickListener(v -> {
                    String message = messageInput.getText().toString().trim();
                    if (!message.isEmpty()) {
                        messages.add(new ChatMessage(ChatMessage.TYPE_USER, message));
                        String response = "I'm analyzing your position...";
                        messages.add(new ChatMessage(ChatMessage.TYPE_COACH, response));
                        adapter.notifyDataSetChanged();
                        recyclerView.scrollToPosition(messages.size() - 1);

                        chessCoach.sendMessage(message, new ChessCoachCallback());
                        messageInput.setText("");
                    }
                });
            }
        }
        isPanelVisible = !isPanelVisible;
    }

    private void startVoiceRecognition() {
        showLoading("Listening...");

        speechRecognitionManager.startListening(new SpeechRecognitionManager.SpeechRecognitionCallback() {
            @Override
            public void onSpeechRecognized(String text) {
                if (!text.isEmpty()) {
                    if (conversationTurns == 0) {
                        processVoiceCommand(text);
                    } else {
                        processFollowUpCommand(text);
                    }
                    conversationTurns++;
                } else {
                    endConversation("I didn't catch that.");
                }
            }

            @Override
            public void onSpeechError(String error) {
                endConversation("Sorry, I had trouble hearing you.");
            }
        });
    }

    private void initializeSpeechRecognition() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    PERMISSION_REQUEST_MICROPHONE);
        } else {
            setupSpeechRecognition();
        }
    }

    private void setupSpeechRecognition() {
        speechRecognitionManager = new SpeechRecognitionManager(this);
    }

    private void initializeChessCoach() {
        // Add this line to pass the controller
        chessCoach.setVoiceController(voiceController);

        // Get API key from secure storage if available
        String apiKey = ApiKeyConfig.getApiKey(this);
        if (apiKey != null && !apiKey.isEmpty()) {
            chessCoach.setApiKey(apiKey);
        }
    }

    private void processVoiceCommand(String command) {
        Log.d(TAG, "Voice command: " + command);
        Toast.makeText(this, "You said: " + command, Toast.LENGTH_SHORT).show();

        String currentFen = engine.getCurrentFEN();
        List<String> moveHistory = gameViewModel.getMoveHistory().getValue();
        if (moveHistory == null) {
            moveHistory = new ArrayList<>();
        }

        GameStateInfo gameState = new GameStateInfo(
                currentFen,
                moveHistory,
                playerColorChoice
        );

        showLoading("Coach is analyzing your request...");
        chessCoach.getEnhancedChessAdvice(gameState, new ChessCoachCallback());
    }

    private void processFollowUpCommand(String command) {
        Log.d(TAG, "Follow-up command: " + command);
        Toast.makeText(this, "You said: " + command, Toast.LENGTH_SHORT).show();

        String contextualPrompt =
                "This is a follow-up question in our conversation.\n\n" +
                        "Current board position: " + engine.getCurrentFEN() + "\n" +
                        "I'm playing as " + playerColorChoice + ".\n" +
                        "My follow-up question is: " + command;

        showLoading("Coach is thinking...");
        chessCoach.sendMessage(contextualPrompt, new ConversationContinuingCallback());
    }

    private void endConversation(String message) {
        inConversationMode = false;
        if (message != null && !message.isEmpty()) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
    }

    private void initializeStockfishEngine(int skillLevel) {
        try {
            File engineFile = new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so");

            if (!engineFile.exists()) {
                Log.d(TAG, "Stockfish not found in native library dir, trying assets fallback");
                try {
                    engineFile = Utils.copyAssetToExecutableDir(this, "stockfish", "stockfish");
                } catch (IOException e) {
                    Log.e(TAG, "Failed to extract Stockfish from assets", e);
                }
            }

            if (!engineFile.exists() || !engineFile.canExecute()) {
                Toast.makeText(this, "Stockfish engine not found", Toast.LENGTH_LONG).show();
                return;
            }

            Log.d(TAG, "Found Stockfish at: " + engineFile.getAbsolutePath());

            engine = new StockfishManager();
            if (engine.startEngine(engineFile.getAbsolutePath())) {
                int engineElo = getIntent().getIntExtra("ENGINE_ELO", 1500);
                engine.setSkillLevel(skillLevel);

                if (skillLevel < 10) {
                    engine.setEngineStrength(engineElo);
                } else {
                    engine.setOption("UCI_LimitStrength", "false");
                }

                if (skillLevel < 5) {
                    engine.setOption("Depth", "2");
                } else if (skillLevel < 10) {
                    engine.setOption("Depth", "5");
                } else if (skillLevel < 15) {
                    engine.setOption("Depth", "8");
                } else {
                    engine.setOption("Depth", "16");
                }

                engine.newGame();
                gameManager = new ChessGameManager(engine);
                setupChessBoard();

                Toast.makeText(this, "Stockfish engine initialized successfully",
                        Toast.LENGTH_SHORT).show();

                updateStatusText("Game ready! " +
                        (playerColorChoice.equalsIgnoreCase("white") ? "White" : "Black") +
                        " to move");
            } else {
                Toast.makeText(this, "Failed to start Stockfish engine",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing Stockfish", e);
            Toast.makeText(this, "Error: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void setupChessBoard() {
        boardView.setFlipped(playerColorChoice.equalsIgnoreCase("black"));

        String startPos = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
        Log.d(TAG, "📋 Setting up board with starting position: " + startPos);
        boardView.updateBoardFromFen(startPos);

        algebraicMoveHistory = new ArrayList<>();
        Log.d(TAG, "Move history reset for new game");

        boardView.setOnSquareTapListener(new ChessBoardView.OnSquareTapListener() {
            @Override
            public void onSquareTapped(int row, int col) {
                Log.d(TAG, "BOARD TAP EVENT RECEIVED at " + row + "," + col);
                handleBoardTap(row, col);
            }
        });
    }

    private void handleBoardTap(int row, int col) {
        Log.d(TAG, "Tap received at: " + row + "," + col);

        // Get info about tapped piece
        char tappedPiece = boardView.getPieceAt(row, col);
        boolean isTappingOwnPiece = isPlayerPiece(tappedPiece);

        // Only allow moves if it's the player's turn
        if (!gameViewModel.isPlayerTurn().getValue()) {
            statusTextView.setText("Please wait for the engine to move");
            return;
        }

        // Get the currently selected square, if any
        int selectedRow = boardView.getSelectedRow();
        int selectedCol = boardView.getSelectedCol();

        // Case 1: A piece is already selected AND tapping another own piece - change selection
        if (selectedRow != -1 && isTappingOwnPiece) {
            Log.d(TAG, "Changing selection to piece at " + row + "," + col);
            boardView.clearHighlightedSquares();
            boardView.setSelectedSquare(row, col);
            showLegalMovesFor(row, col);
            return;
        }

        // Case 2: No piece selected yet, and tapping own piece
        if (selectedRow == -1 && isTappingOwnPiece && gameViewModel.isPlayerTurn().getValue()) {
            Log.d(TAG, "✅ Selecting piece at " + row + "," + col);
            boardView.setSelectedSquare(row, col);
            showLegalMovesFor(row, col);
            return;
        }

        // Case 3: Making a move (piece already selected and tapping destination)
        if (selectedRow != -1) {
            String moveUci = convertToUCI(selectedRow, selectedCol, row, col);
            Log.d(TAG, "Attempting move: " + moveUci);
            gameViewModel.makePlayerMove(moveUci);
        }
    }

    // Add these methods to MainActivity.java

    // 5. Test method for WebSocket communication
    private void testWebSocketCommunication() {
        // Run this after establishing connection
        new Handler().postDelayed(() -> {
            try {
                Log.d(TAG, "Sending test message to OpenAI");

                // This line needs to be adjusted based on your implementation
                audioConversationManager.sendUserText("What's a good opening for black against e4?");

                Toast.makeText(this, "Test message sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e(TAG, "Failed to send test message", e);
                Toast.makeText(this, "Test failed: " + e.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        }, 5000); // Wait 5 seconds after connection
    }

    // 6. Network connectivity check
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        boolean connected = activeNetworkInfo != null && activeNetworkInfo.isConnected();

        Log.d(TAG, "Network available? " + connected);
        return connected;
    }

    private boolean isPlayerPiece(char piece) {
        if (piece == ' ') return false;

        boolean isPieceWhite = Character.isUpperCase(piece);
        boolean isPlayerWhite = playerColorChoice.equalsIgnoreCase("white");

        return isPieceWhite == isPlayerWhite;
    }

    private void updateBoardDisplay() {
        boardView.updateBoardFromFen(engine.getCurrentFEN());
    }

    private String convertToUCI(int fromRow, int fromCol, int toRow, int toCol) {
        char fromFile = (char) ('a' + fromCol);
        int fromRank = 8 - fromRow;
        char toFile = (char) ('a' + toCol);
        int toRank = 8 - toRow;
        return "" + fromFile + fromRank + toFile + toRank;
    }

    private void showLegalMovesFor(int row, int col) {
        boardView.clearHighlightedSquares();
        List<String> legalMoves = engine.getLegalMovesForPiece(row, col);

        for (String move : legalMoves) {
            if (move.length() >= 4) {
                int targetCol = move.charAt(2) - 'a';
                int targetRow = 8 - (move.charAt(3) - '0');
                boardView.addHighlightedSquare(targetRow, targetCol);
            }
        }

        boardView.invalidate();
    }




    private void updateMoveHistoryView(List<String> moves) {
        moveHistoryBuilder = new StringBuilder();
        moveNumber = 1;

        for (int i = 0; i < moves.size(); i++) {
            boolean isWhiteMove = (i % 2 == 0);
            if (isWhiteMove) {
                moveHistoryBuilder.append(moveNumber).append(". ").append(moves.get(i));
            } else {
                moveHistoryBuilder.append(" ").append(moves.get(i)).append("\n");
                moveNumber++;
            }
        }

        if (moveHistoryTextView != null) {
            moveHistoryTextView.setText(moveHistoryBuilder.toString());
        }
    }

    private void performHapticFeedback(String moveType) {
        if (vibrator != null && vibrator.hasVibrator()) {
            switch (moveType) {
                case "move":
                    vibrator.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE));
                    break;
                case "capture":
                    vibrator.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE));
                    break;
                case "check":
                    long[] pattern = {0, 30, 80, 30};
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
                    break;
            }
        }
    }

    private String determineMoveType(String moveUci) {
        int fromCol = moveUci.charAt(0) - 'a';
        int fromRow = 8 - Character.getNumericValue(moveUci.charAt(1));
        int toCol = moveUci.charAt(2) - 'a';
        int toRow = 8 - Character.getNumericValue(moveUci.charAt(3));

        char pieceAtDestination = boardView.getPieceAt(toRow, toCol);
        if (pieceAtDestination != ' ') {
            return "capture";
        }

        return "move";
    }

    private String determineMoveType(String moveUci, String fen) {
        String baseType = determineMoveType(moveUci);

        if (fen != null) {
            if (fen.contains("#")) {
                return "checkmate";
            } else if (fen.contains("+")) {
                return "check";
            }
        }

        return baseType;
    }



    // Add these methods to your MainActivity class
    private void startRealtimeConversation() {
        // Check microphone permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    PERMISSION_REQUEST_MICROPHONE);
            return;
        }

        // Update current game state
        GameStateInfo gameState = GameStateRepository.getCurrentState();

        // Connect using existing AudioConversationManager
        // (keeps compatibility with your codebase)
        audioConversationManager.connect(ApiKeyConfig.getApiKey(this));

        // Use integration helper to start conversation
        conversationModeActive = true;
        updateConversationButtonState();

        // Start the conversation via the integration helper
        integrationHelper.startConversation(gameState);

        // Update UI
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        bottomSheetMessageText.setText("Connecting to your chess coach...");
    }

    private void stopRealtimeConversation() {
        if (realtimeManager != null) {
            realtimeManager.endConversation("Thanks for chatting! I'm here if you need more help with your game.");
        }

        // Also update the conversation mode flag and UI
        conversationModeActive = false;
        updateConversationButtonState();
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
    }

    private String convertToAlgebraic(String uciMove) {
        if (uciMove == null || uciMove.length() < 4) return "?";

        int fromCol = uciMove.charAt(0) - 'a';
        int fromRow = 8 - Character.getNumericValue(uciMove.charAt(1));
        char piece = boardView.getPieceAt(fromRow, fromCol);

        String pieceLetter = "";
        switch (Character.toUpperCase(piece)) {
            case 'R': pieceLetter = "R"; break;
            case 'N': pieceLetter = "N"; break;
            case 'B': pieceLetter = "B"; break;
            case 'Q': pieceLetter = "Q"; break;
            case 'K': pieceLetter = "K"; break;
        }

        String destSquare = uciMove.substring(2, 4);
        return pieceLetter + destSquare;
    }

    private void promptForApiKeyIfNeeded() {
        if (!ApiKeyConfig.hasApiKey(this)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("OpenAI API Key Required");
            builder.setMessage("To use the chess coach feature, you need to enter your OpenAI API key.");

            final EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_TEXT);
            input.setHint("Enter your OpenAI API key");
            builder.setView(input);

            builder.setPositiveButton("Save", (dialog, which) -> {
                String apiKey = input.getText().toString().trim();
                if (!apiKey.isEmpty()) {
                    ApiKeyConfig.saveApiKey(this, apiKey);
                    chessCoach.setApiKey(apiKey);
                    Toast.makeText(this, "API key saved", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> {
                dialog.cancel();
                Toast.makeText(this, "Chess coach features will be unavailable", Toast.LENGTH_LONG).show();
            });

            builder.show();
        } else {
            String apiKey = ApiKeyConfig.getApiKey(this);
            if (apiKey != null && !apiKey.isEmpty()) {
                chessCoach.setApiKey(apiKey);
            }
        }
    }

    private void showLoading(String message) {
        bottomSheetMessageText.setText(message);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

        if (bottomSheetRespondButton != null) {
            bottomSheetRespondButton.setVisibility(View.GONE);
        }
    }

    private void initializeRealtimeConversation() {

        safelyInitializeViews();

/**
 * Safe initialization helper for UI elements
 * Checks if views exist before attempting to use them
 */
        private void safelyInitializeViews() {
            // Log initialization state for debugging
            Log.d(TAG, "Safely initializing conversation-related views");

            // Check for conversation button (FAB)
            if (findViewById(R.id.conversationButton) != null) {
                conversationButton = findViewById(R.id.conversationButton);
                Log.d(TAG, "Found conversation button");
            } else {
                Log.d(TAG, "Conversation button not found in layout");
            }

            // Check for bottom sheet
            if (findViewById(R.id.coachBottomSheet) != null) {
                coachBottomSheet = findViewById(R.id.coachBottomSheet);
                Log.d(TAG, "Found coach bottom sheet");
            } else {
                Log.d(TAG, "Coach bottom sheet not found in layout");
            }

            // Check for bottom sheet message text
            if (findViewById(R.id.bottomSheetMessageText) != null) {
                bottomSheetMessageText = findViewById(R.id.bottomSheetMessageText);
                Log.d(TAG, "Found bottom sheet message text");
            } else {
                Log.d(TAG, "Bottom sheet message text not found in layout");
            }

            // Check for bottom sheet behavior
            if (coachBottomSheet != null) {
                try {
                    bottomSheetBehavior = BottomSheetBehavior.from(coachBottomSheet);
                    Log.d(TAG, "Successfully set up bottom sheet behavior");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to get BottomSheetBehavior from coachBottomSheet", e);
                }
            }
        }


        // Check if we already have a conversation manager in your existing code
        if (audioConversationManager == null) {
            // Create a transcript TextView if needed
            TextView transcript = findViewById(R.id.transcript);
            if (transcript == null) {
                // If no transcript view exists, we can use the bottom sheet message text
                transcript = bottomSheetMessageText;
            }

            // Create the audio conversation manager from your existing code
            audioConversationManager = new AudioConversationManager(transcript);
        }

        // Get API key from your secure storage
        String apiKey = ApiKeyConfig.getApiKey(this);
        if (apiKey != null && !apiKey.isEmpty()) {
            audioConversationManager.setApiKey(apiKey);

            // Set system prompt from your existing code
            String systemPrompt = "You are Coach Tal, a brilliant attacking chess master and the 8th World Chess Champion. " +
                    "Your tactical vision and creativity are legendary. When analyzing positions, you MUST:\n\n" +
                    "- Begin your VERY FIRST SENTENCE by directly referencing a specific move from the history\n" +
                    "- If at starting position: \"I see we're at the starting position with no moves played yet.\"\n" +
                    "- NEVER give generic advice without tying it to specific moves in THIS game\n" +
                    "- Look for tactical opportunities and creative possibilities, just as Tal would";
            audioConversationManager.setSystemPrompt(systemPrompt);
        } else {
            Log.e(TAG, "API key not available - voice conversations will not work");
            Toast.makeText(this, "Please set your OpenAI API key in settings", Toast.LENGTH_LONG).show();
        }

        // Create the new realtime manager
        realtimeManager = new RealtimeConversationManager(this);

        // Create a speech recognition manager if needed
        SpeechRecognitionManager speechManager = new SpeechRecognitionManager(this);
        realtimeManager.setSpeechRecognitionManager(speechManager);

        // Set API key for realtime manager
        if (apiKey != null && !apiKey.isEmpty()) {
            realtimeManager.setApiKey(apiKey);
        }

        // Create integration helper to bridge your existing code with the new system
        integrationHelper = new ConversationIntegrationHelper(this, realtimeManager);

        // Transfer any existing listener to the integration helper
        if (audioConversationManager.getConversationListener() != null) {
            integrationHelper.setOriginalListener(audioConversationManager.getConversationListener());
        }

        // Set up the conversation button click listener
        conversationButton.setOnClickListener(v -> {
            if (conversationModeActive) {
                stopRealtimeConversation();
            } else {
                startRealtimeConversation();
            }
        });

        // Set up the bottom sheet click listener for interruptions
        coachBottomSheet.setOnClickListener(v -> {
            // Interrupt speech and start listening when user taps anywhere on the sheet
            if (conversationModeActive) {
                if (realtimeManager != null) {
                    realtimeManager.interruptCurrentSpeech();
                    Toast.makeText(MainActivity.this, "I'm listening!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    private void updateConversationButtonState() {
        // Update the FAB icon based on conversation state
        if (conversationModeActive) {
            conversationButton.setImageResource(android.R.drawable.ic_media_pause);
        } else {
            conversationButton.setImageResource(android.R.drawable.ic_media_play);
        }
    }


    private void showCoachMessage(String message) {
        bottomSheetMessageText.setText(message);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

        if (bottomSheetRespondButton != null) {
            bottomSheetRespondButton.setVisibility(View.VISIBLE);
        }
    }

    private void hideCoachMessage() {
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        chessCoach.stopSpeaking();
    }

    private void updateStatusText(String message) {
        if (statusTextView != null) {
            statusTextView.setText(message);
        }
    }

    private void promptForFollowUpQuestion() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Follow-up Question");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("Ask your follow-up question");
        builder.setView(input);

        builder.setPositiveButton("Ask", (dialog, which) -> {
            String question = input.getText().toString().trim();
            if (!question.isEmpty()) {
                showLoading("Coach is thinking...");
                chessCoach.sendMessage(question, new ChessCoachCallback());
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private class ChessCoachCallback implements ChessCoachManager.ChessCoachCallback {
        @Override
        public void onResponseReceived(String response) {
            showCoachMessage(response);
        }

        @Override
        public void onError(String errorMessage) {
            Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
            hideCoachMessage();
        }

        @Override
        public void onSpeechCompleted() {
            // Speech has completed, can perform any needed actions here
        }
    }

    private class ConversationContinuingCallback implements ChessCoachManager.ChessCoachCallback {
        @Override
        public void onResponseReceived(String response) {
            showCoachMessage(response);
        }

        @Override
        public void onError(String errorMessage) {
            Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
            endConversation(null);
        }

        @Override
        public void onSpeechCompleted() {
            Log.d(TAG, "ConversationContinuingCallback.onSpeechCompleted called. inConversationMode="
                    + inConversationMode + ", conversationTurns=" + conversationTurns);

            if (inConversationMode && conversationTurns < MAX_CONVERSATION_TURNS) {
                new Handler().postDelayed(() -> {
                    runOnUiThread(() -> {
                        startVoiceRecognition();
                    });
                }, 1500); // 1.5 second pause
            } else {
                endConversation("Thanks for the conversation!");
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_MICROPHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, start conversation
                startRealtimeConversation();
            } else {
                Toast.makeText(this, "Microphone permission required for voice conversation",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_save_game) {
            showSaveGameDialog();
            return true;
        }
        else if (id == R.id.action_load_game) {
            openSavedGamesScreen();
            return true;
        }
        else if (id == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showSaveGameDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Save Game");

        final EditText input = new EditText(this);
        input.setHint("Enter a description for this game");
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String description = input.getText().toString().trim();
                if (description.isEmpty()) {
                    description = "Game on " + new Date().toString();
                }

                GameDatabaseHelper dbHelper = new GameDatabaseHelper(MainActivity.this);
                dbHelper.saveGame(
                        playerColorChoice,
                        algebraicMoveHistory,
                        engine.getCurrentFEN(),
                        description
                );

                Toast.makeText(MainActivity.this, "Game saved successfully!", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void openSavedGamesScreen() {
        Intent intent = new Intent(this, SavedGamesActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (convo != null) {
            convo.close();
        }
        if (audioConversationManager != null) {
            audioConversationManager.release();
        }

        // Clean up the conversation resources
        if (realtimeManager != null) {
            realtimeManager.shutdown();
        }

        if (engine != null) {
            engine.stopEngine();
        }
        SoundManager.release();

        if (chessCoach != null) {
            chessCoach.shutdown();
        }

        // Clean up the conversation manager
        if (chessCoachConversation != null) {
            chessCoachConversation.shutdown();
        }

        if (speechRecognitionManager != null) {
            speechRecognitionManager.release();
        }
    }
}
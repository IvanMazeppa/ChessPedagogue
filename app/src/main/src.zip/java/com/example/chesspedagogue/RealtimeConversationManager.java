package com.example.chesspedagogue;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * Manages realtime voice conversations with OpenAI's streaming API
 * Provides a seamless, interruptible speech-to-speech experience
 */
public class RealtimeConversationManager {
    private static final String TAG = "RealtimeConversation";
    private static final String REALTIME_API_URL = "wss://api.openai.com/v1/realtime";

    // Interface for listening to conversation state changes
    public interface ConversationStateListener {
        void onPassiveListening();
        void onListening();
        void onProcessing();
        void onSpeaking(String text);
        void onPartialResponse(String partialText);
        void onError(String message);
        void onConversationEnded();
    }

    private Context context;
    private String apiKey;
    private WebSocket webSocket;
    private OkHttpClient client;
    private Handler mainHandler;
    private ConversationStateListener stateListener;
    private SpeechRecognitionManager speechRecognitionManager;
    private OpenAITTSService ttsService;
    private AtomicBoolean isConnected = new AtomicBoolean(false);
    private AtomicBoolean isListening = new AtomicBoolean(false);
    private AtomicBoolean isSpeaking = new AtomicBoolean(false);
    private StringBuilder currentResponseText = new StringBuilder();
    private String modelName = "gpt-4o-realtime-preview-2024-12-17";

    // State of the conversation
    private enum State {
        IDLE, CONNECTING, LISTENING, PROCESSING, SPEAKING
    }
    private State currentState = State.IDLE;
    private GameStateInfo currentGameState;

    /**
     * Create a new realtime conversation manager
     */
    public RealtimeConversationManager(Context context) {
        this.context = context.getApplicationContext();
        this.mainHandler = new Handler(Looper.getMainLooper());

        // Initialize TTS service
        this.ttsService = OpenAITTSService.getInstance(context);

        // Configure OkHttp with proper timeouts for WebSocket
        this.client = new OkHttpClient.Builder()
                .pingInterval(20, TimeUnit.SECONDS)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    /**
     * Set the API key for OpenAI
     */
    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
        if (ttsService != null) {
            ttsService.setApiKey(apiKey);
        }
    }

    /**
     * Set speech recognition manager
     */
    public void setSpeechRecognitionManager(SpeechRecognitionManager manager) {
        this.speechRecognitionManager = manager;
    }

    /**
     * Set conversation state listener
     */
    public void setConversationStateListener(ConversationStateListener listener) {
        this.stateListener = listener;
    }

    /**
     * Connect to OpenAI's realtime WebSocket API
     */
    public void connect() {
        if (isConnected.get()) return;

        if (apiKey == null || apiKey.isEmpty()) {
            Log.e(TAG, "API key not set");
            if (stateListener != null) {
                stateListener.onError("API key not set");
            }
            return;
        }

        setState(State.CONNECTING);

        // Create WebSocket request with proper headers
        Request request = new Request.Builder()
                .url(REALTIME_API_URL + "?model=" + modelName)
                .addHeader("Authorization", "Bearer " + apiKey)
                .addHeader("OpenAI-Beta", "realtime=v1")
                .build();

        Log.d(TAG, "Connecting to WebSocket: " + request.url());

        // Open WebSocket connection
        webSocket = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                Log.d(TAG, "WebSocket connected: " + response.code() + " " + response.message());

                // Update state and notify listener on main thread
                mainHandler.post(() -> {
                    isConnected.set(true);
                    if (stateListener != null) {
                        // Notify listener of successful connection
                        // Using onListening instead of onConnected since that's in your interface
                        stateListener.onListening();
                    }

                    // Send system prompt to establish the coach persona
                    sendSystemMessage(CHESS_COACH_SYSTEM_PROMPT);
                });
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                Log.d(TAG, "Received message: " + text);

                try {
                    // Handle DONE message
                    if (text.equals("[\"DONE\"]")) {
                        mainHandler.post(() -> {
                            Log.d(TAG, "Stream completed");
                            // Transition back to listening mode when done speaking
                            if (currentState == State.SPEAKING) {
                                transitionToListening();
                            }
                        });
                        return;
                    }

                    // Parse JSON message
                    JSONObject message = new JSONObject(text);
                    String type = message.optString("type", "unknown");

                    // Process different message types
                    mainHandler.post(() -> {
                        switch (type) {
                            case "response.text.delta":
                                String delta = message.optString("delta", "");
                                handleTextDelta(delta);
                                break;

                            case "response.text.done":
                                handleTextDone();
                                break;

                            case "response.audio.delta":
                                String audioBase64 = message.optString("audio", "");
                                if (!audioBase64.isEmpty()) {
                                    playAudioChunk(audioBase64);
                                }
                                break;

                            case "response.done":
                                handleResponseDone();
                                break;

                            case "error":
                                JSONObject error = message.optJSONObject("error");
                                if (error != null) {
                                    String errorMessage = error.optString("message", "Unknown error");
                                    Log.e(TAG, "API error: " + errorMessage);
                                    if (stateListener != null) {
                                        stateListener.onError(errorMessage);
                                    }
                                }
                                break;

                            default:
                                Log.d(TAG, "Unhandled message type: " + type);
                                break;
                        }
                    });

                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing message: " + e.getMessage());
                }
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                String responseCode = response != null ? " (" + response.code() + ")" : "";
                Log.e(TAG, "WebSocket failure" + responseCode, t);

                mainHandler.post(() -> {
                    isConnected.set(false);
                    if (stateListener != null) {
                        stateListener.onError("Connection error: " + t.getMessage());
                    }

                    // Attempt reconnection with backoff
                    attemptReconnect();
                });
            }

            @Override
            public void onClosed(WebSocket webSocket, int code, String reason) {
                Log.d(TAG, "WebSocket closed: " + code + " " + reason);

                mainHandler.post(() -> {
                    isConnected.set(false);
                });
            }
        });
    }

    /**
     * Start a conversation with the chess coach
     */
    public void startConversation(GameStateInfo gameState) {
        if (!isConnected.get()) {
            connect();
            return;
        }

        // Store the game state for context
        if (gameState != null) {
            this.currentGameState = gameState;
        }

        // Generate a greeting based on the game state
        String greeting = generateGreeting();

        // Start with coach greeting
        sendAssistantMessage(greeting);

        // Then transition to listening mode
        transitionToListening();
    }

    /**
     * Generate a contextual greeting based on game state
     */
    private String generateGreeting() {
        if (currentGameState == null) {
            return "Hello! I'm Coach Tal. How can I help with your chess game?";
        }

        // Customize based on game phase
        if (currentGameState.getMoveCount() < 6) {
            return "Hi! I see we're in the opening phase. What would you like to know about your position?";
        } else if (currentGameState.getMoveCount() < 30) {
            return "Hello! We're in the middle game now. How can I help with your strategy?";
        } else {
            return "I see we're in the endgame. Would you like some advice on your position?";
        }
    }

    /**
     * Handle text delta from the API response
     */
    private void handleTextDelta(String delta) {
        // Append to the current response
        currentResponseText.append(delta);

        // If this is the first delta, transition to SPEAKING
        if (currentState == State.PROCESSING) {
            setState(State.SPEAKING);
        }

        // Update UI with the partial text
        if (stateListener != null) {
            stateListener.onPartialResponse(currentResponseText.toString());
        }
    }

    /**
     * Handle text completion
     */
    private void handleTextDone() {
        // Full response is now in currentResponseText
        Log.d(TAG, "Response complete: " + currentResponseText.toString());

        // Begin speaking the response if we're not already speaking audio
        if (!isSpeaking.get()) {
            speakResponse(currentResponseText.toString());
        }
    }

    /**
     * Handle complete response
     */
    private void handleResponseDone() {
        Log.d(TAG, "Response completed");
    }

    /**
     * Speak the response using TTS
     */
    private void speakResponse(String text) {
        isSpeaking.set(true);

        // Use TTS to speak the text
        ttsService.speak(text, OpenAITTSService.VOICE_GRANDMASTER, OpenAITTSService.MODEL_STANDARD,
                new OpenAITTSService.TTSCallback() {
                    @Override
                    public void onSpeechStarted() {
                        Log.d(TAG, "TTS speech started");
                    }

                    @Override
                    public void onSpeechReady(File audioFile) {
                        Log.d(TAG, "TTS speech ready");
                    }

                    @Override
                    public void onSpeechCompleted() {
                        Log.d(TAG, "TTS speech completed");
                        mainHandler.post(() -> {
                            isSpeaking.set(false);
                            transitionToListening();
                        });
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Log.e(TAG, "TTS error: " + errorMessage);
                        mainHandler.post(() -> {
                            isSpeaking.set(false);
                            if (stateListener != null) {
                                stateListener.onError("TTS error: " + errorMessage);
                            }
                            transitionToListening();
                        });
                    }
                });
    }

    /**
     * Play audio chunk from base64 data
     */
    private void playAudioChunk(String base64Audio) {
        // Implementation would decode and play using AudioTrack
        // This would be similar to your existing code in AudioConversationManager
        Log.d(TAG, "Playing audio chunk");

        // Mark that we're speaking
        isSpeaking.set(true);
    }

    /**
     * Transition to listening mode
     */
    private void transitionToListening() {
        isListening.set(true);
        setState(State.LISTENING);

        // Start speech recognition
        if (speechRecognitionManager != null) {
            speechRecognitionManager.startListening(new SpeechRecognitionManager.SpeechRecognitionCallback() {
                @Override
                public void onSpeechRecognized(String text) {
                    Log.d(TAG, "Speech recognized: " + text);

                    // Process the recognized speech
                    handleUserInput(text);
                }

                @Override
                public void onSpeechError(String error) {
                    Log.e(TAG, "Speech recognition error: " + error);

                    // Go back to listening after error
                    mainHandler.postDelayed(() -> transitionToListening(), 1000);
                }
            });
        } else {
            Log.e(TAG, "Speech recognition manager not initialized");
        }
    }

    /**
     * Handle user's speech input
     */
    private void handleUserInput(String text) {
        if (text == null || text.isEmpty()) {
            transitionToListening();
            return;
        }

        // Stop listening and start processing
        isListening.set(false);
        setState(State.PROCESSING);
        currentResponseText = new StringBuilder();

        // Send user message to OpenAI
        sendUserMessage(text);
    }

    /**
     * Attempt reconnection to WebSocket
     */
    private void attemptReconnect() {
        mainHandler.postDelayed(() -> {
            if (!isConnected.get()) {
                Log.d(TAG, "Attempting to reconnect...");
                connect();
            }
        }, 5000); // 5 second delay
    }

    /**
     * Send system message to OpenAI
     */
    private void sendSystemMessage(String content) {
        if (!isConnected.get()) {
            Log.e(TAG, "Cannot send message - not connected");
            return;
        }

        try {
            JSONObject message = new JSONObject();
            message.put("type", "message");
            message.put("role", "system");
            message.put("content", content);

            String json = message.toString();
            Log.d(TAG, "Sending system message: " + json);
            webSocket.send(json);
        } catch (JSONException e) {
            Log.e(TAG, "Error creating system message", e);
        }
    }

    /**
     * Send user message to OpenAI
     */
    private void sendUserMessage(String content) {
        if (!isConnected.get()) {
            Log.e(TAG, "Cannot send message - not connected");
            return;
        }

        try {
            JSONObject message = new JSONObject();
            message.put("type", "message");
            message.put("role", "user");
            message.put("content", content);

            // Include chess context if available
            if (currentGameState != null) {
                message.put("context", formatGameContext(currentGameState));
            }

            String json = message.toString();
            Log.d(TAG, "Sending user message: " + json);
            webSocket.send(json);
        } catch (JSONException e) {
            Log.e(TAG, "Error creating user message", e);
        }
    }

    /**
     * Send assistant message to OpenAI
     */
    private void sendAssistantMessage(String content) {
        try {
            JSONObject message = new JSONObject();
            message.put("type", "message");
            message.put("role", "assistant");
            message.put("content", content);

            String json = message.toString();
            Log.d(TAG, "Sending assistant message: " + json);
            webSocket.send(json);

            // Begin speaking this message
            speakResponse(content);
        } catch (JSONException e) {
            Log.e(TAG, "Error creating assistant message", e);
        }
    }

    /**
     * Format game state for context
     */
    private String formatGameContext(GameStateInfo gameState) {
        StringBuilder context = new StringBuilder();

        // Add FEN position
        context.append("Current position (FEN): ").append(gameState.getCurrentFen()).append("\n\n");

        // Add move history
        List<String> moves = gameState.getMoveHistory();
        if (moves != null && !moves.isEmpty()) {
            context.append("Move history: ");
            int moveNumber = 1;
            for (int i = 0; i < moves.size(); i += 2) {
                context.append(moveNumber).append(". ");
                context.append(moves.get(i));

                if (i + 1 < moves.size()) {
                    context.append(" ").append(moves.get(i + 1));
                }
                context.append(" ");
                moveNumber++;
            }
            context.append("\n");
        }

        // Add player color
        context.append("Player is playing as: ").append(gameState.getPlayerColor()).append("\n");

        return context.toString();
    }

    /**
     * Start continuous listening
     */
    public void startListening() {
        if (currentState != State.LISTENING) {
            transitionToListening();
        }
    }

    /**
     * Ensure listening has started (failsafe)
     */
    public void ensureListeningStarted() {
        if (currentState != State.LISTENING &&
                currentState != State.PROCESSING &&
                currentState != State.SPEAKING) {
            startListening();
        }
    }

    /**
     * Interrupt current speech and start listening
     */
    public void interruptCurrentSpeech() {
        if (isSpeaking.get()) {
            // Stop TTS
            if (ttsService != null) {
                ttsService.stopPlayback();
            }

            isSpeaking.set(false);
            transitionToListening();
        }
    }

    /**
     * End the conversation
     */
    public void endConversation(String finalMessage) {
        // Speak a final message if provided
        if (finalMessage != null && !finalMessage.isEmpty()) {
            speakResponse(finalMessage);
        }

        // Close connection
        if (webSocket != null) {
            webSocket.close(1000, "Conversation ended");
        }

        setState(State.IDLE);

        // Notify listener
        if (stateListener != null) {
            stateListener.onConversationEnded();
        }
    }

    /**
     * Set the current state and notify listener
     */
    private void setState(State newState) {
        currentState = newState;

        if (stateListener != null) {
            switch (newState) {
                case LISTENING:
                    stateListener.onListening();
                    break;
                case PROCESSING:
                    stateListener.onProcessing();
                    break;
                case SPEAKING:
                    stateListener.onSpeaking(currentResponseText.toString());
                    break;
                case IDLE:
                    // No specific state notification
                    break;
            }
        }
    }

    /**
     * Clean up resources
     */
    public void shutdown() {
        if (webSocket != null) {
            webSocket.close(1000, "Shutdown");
        }

        if (ttsService != null) {
            ttsService.stopPlayback();
        }
    }

    /**
     * Chess coach system prompt
     */
    private static final String CHESS_COACH_SYSTEM_PROMPT =
            "You are Coach Tal, a brilliant attacking chess master and the 8th World Chess Champion. " +
                    "Your tactical vision and creativity are legendary. When analyzing positions, you MUST:\n\n" +
                    "- Begin your VERY FIRST SENTENCE by directly referencing a specific move from the history\n" +
                    "- If at starting position: \"I see we're at the starting position with no moves played yet.\"\n" +
                    "- NEVER give generic advice without tying it to specific moves in THIS game\n" +
                    "- Look for tactical opportunities and creative possibilities, just as Tal would\n\n" +
                    "Your analysis should feel personally tailored to this exact position and move history.";
}